import { Text, View, StyleSheet, Image } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.paragraph}>
      <Text style={styles.paragraph}>
        Fullname: Nguyễn Duy Khoa
      </Text>
      <Text style={styles.paragraph}>
        Phone: 0943620548
      </Text>
      <Text style={styles.paragraph}>
        Student ID: 220501013
      </Text>
      <Text style={styles.paragraph}>
        Email: 220501013@gmail.com
      </Text>
      <Text style={styles.paragraph}>
        Hobbies: Play game
      </Text>
         
      <Image style={styles.logo} source={require('../assets/cr7.jpg')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  paragraph: {
    margin: 10,
    marginTop: 5,
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'left',
  },
  logo: {
    height: 228,
    width: 400,
  }
});
